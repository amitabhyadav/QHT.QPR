# QCQI
A repository for quantum computing and quantum information that I enjoy working on in my "free time."

## License
The content of this project itself is licensed under the [Creative Commons Attribution 3.0 Unported license](https://creativecommons.org/licenses/by/3.0/), and the underlying source code used to format and display that content is licensed under the [GNU General Public License v3.0](https://www.gnu.org/licenses/gpl-3.0.html).
